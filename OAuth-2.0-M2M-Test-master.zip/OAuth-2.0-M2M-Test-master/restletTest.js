/**
 * @NApiVersion 2.1
 * @NScriptType Restlet
 */
define([], () => {

    const get = () => {
        return {
            success: true,
            message: 'RESTlet working'
        };
    };

    return { get };

});