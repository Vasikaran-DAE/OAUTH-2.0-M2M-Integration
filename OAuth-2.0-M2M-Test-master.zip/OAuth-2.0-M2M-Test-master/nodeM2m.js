const axios = require('axios');
const jwt = require('jsonwebtoken');
const fs = require('fs');
const qs = require('qs');

// =====================
// CONFIG
// =====================

const ACCOUNT_ID = '5739430-sb2';
const CLIENT_ID = 'cec6a6d533766f23dfc33127fffa0483410f02455413cd31ba5d0e8622475195';
const CERTIFICATE_ID = '8tmLngobyoFFa3Q7hD1vkYCuwvoXJeuo-Ij2PEo-Ub0';

const PRIVATE_KEY = fs.readFileSync('./private.pem');

const RESTLET_SCRIPT_ID = 'customscriptrestlet_m2m_test';
const RESTLET_DEPLOY_ID = 'customdeployrestlet_m2m_test';

// remove underscores and lowercase
const ACCOUNT_ID_CLEAN = ACCOUNT_ID.replace('_', '-').toLowerCase();

const TOKEN_URL =
    `https://${ACCOUNT_ID_CLEAN}.suitetalk.api.netsuite.com/services/rest/auth/oauth2/v1/token`;


// =====================
// CREATE JWT
// =====================

const now = Math.floor(Date.now() / 1000);

const payload = {
    iss: CLIENT_ID,
    scope: ['restlets'],
    aud: TOKEN_URL,
    iat: now,
    exp: now + 3600
};

const token = jwt.sign(
    payload,
    PRIVATE_KEY,
    {
        algorithm: 'PS256',
        header: {
            typ: 'JWT',
            kid: CERTIFICATE_ID
        }
    }
);


// =====================
// GET ACCESS TOKEN
// =====================

async function getAccessToken() {

    const response = await axios.post(
        TOKEN_URL,
        qs.stringify({
            grant_type: 'client_credentials',
            client_assertion_type:
                'urn:ietf:params:oauth:client-assertion-type:jwt-bearer',
            client_assertion: token
        }),
        {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        }
    );

    return response.data.access_token;
}


// =====================
// CALL RESTLET
// =====================

async function callRestlet(accessToken) {

    const url =
        `https://${ACCOUNT_ID_CLEAN}.restlets.api.netsuite.com/app/site/hosting/restlet.nl` +
        `?script=${RESTLET_SCRIPT_ID}` +
        `&deploy=${RESTLET_DEPLOY_ID}`;

    const response = await axios.get(url, {
        headers: {
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
        }
    });

    console.log(response.data);
}


// =====================
// MAIN
// =====================

(async () => {

    try {

        const accessToken = await getAccessToken();

        console.log('Access Token Generated');

        await callRestlet(accessToken);

    } catch (err) {

        console.error(
            err.response?.data || err.message
        );

    }

})();